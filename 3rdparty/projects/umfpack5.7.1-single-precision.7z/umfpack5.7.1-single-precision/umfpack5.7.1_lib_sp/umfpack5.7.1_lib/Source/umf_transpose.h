/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL Int UMF_transpose
(
    Int n_row,
    Int n_col,
    const Int Ap [ ],
    const Int Ai [ ],
    const UMFPACK_MYFLOAT Ax [ ],
    const Int P [ ],
    const Int Q [ ],
    Int nq,
    Int Rp [ ],
    Int Ri [ ],
    UMFPACK_MYFLOAT Rx [ ],
    Int W [ ],
    Int check
#ifdef COMPLEX
    , const UMFPACK_MYFLOAT Az [ ]
    , UMFPACK_MYFLOAT Rz [ ]
    , Int do_conjugate
#endif
) ;
