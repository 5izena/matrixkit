/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL void UMF_set_stats
(
    UMFPACK_MYFLOAT Info [ ],
    SymbolicType *Symbolic,
    UMFPACK_MYFLOAT max_usage,
    UMFPACK_MYFLOAT num_mem_size,
    UMFPACK_MYFLOAT flops,
    UMFPACK_MYFLOAT lnz,
    UMFPACK_MYFLOAT unz,
    UMFPACK_MYFLOAT maxfrsize,
    UMFPACK_MYFLOAT ulen,
    UMFPACK_MYFLOAT npiv,
    UMFPACK_MYFLOAT maxnrows,
    UMFPACK_MYFLOAT maxncols,
    Int scale,
    Int prefer_diagonal,
    Int what
) ;
