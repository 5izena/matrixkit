/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL Int UMF_solve
(
    Int sys,
    const Int Ap [ ],
    const Int Ai [ ],
    const UMFPACK_MYFLOAT Ax [ ],
    UMFPACK_MYFLOAT Xx [ ],
    const UMFPACK_MYFLOAT Bx [ ],
#ifdef COMPLEX
    const UMFPACK_MYFLOAT Az [ ],
    UMFPACK_MYFLOAT Xz [ ],
    const UMFPACK_MYFLOAT Bz [ ],
#endif
    NumericType *Numeric,
    Int irstep,
    UMFPACK_MYFLOAT Info [UMFPACK_INFO],
    Int Pattern [ ],
    UMFPACK_MYFLOAT SolveWork [ ]
) ;
