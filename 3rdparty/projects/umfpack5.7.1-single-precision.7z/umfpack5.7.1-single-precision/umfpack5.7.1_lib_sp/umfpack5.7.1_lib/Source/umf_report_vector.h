/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL Int UMF_report_vector
(
    Int n,
    const UMFPACK_MYFLOAT Xx [ ],
    const UMFPACK_MYFLOAT Xz [ ],
    Int prl,
    Int user,
    Int scalar
) ;
